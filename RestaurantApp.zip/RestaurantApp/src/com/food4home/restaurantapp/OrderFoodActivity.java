package com.food4home.restaurantapp;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class OrderFoodActivity extends FragmentActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_order_food);
	}
}
