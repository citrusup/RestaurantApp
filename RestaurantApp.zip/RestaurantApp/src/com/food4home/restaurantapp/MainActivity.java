package com.food4home.restaurantapp;

//import com.example.mapdemo.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.food4home.restaurantapp.MapActivity;

public class MainActivity extends FragmentActivity implements OnClickListener {
	private Button nearestLocation;
	private Button orderFood;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		nearestLocation = (Button) findViewById(R.id.nearest_location_button);
		orderFood = (Button) findViewById(R.id.order_food_button);
		turnOnGpsDialog();
	}

	@Override
	protected void onStart() {
		super.onStart();

	}

	@Override
	protected void onStop() {
		super.onStop();

	}

	@Override
	protected void onResume() {
		super.onResume();
		nearestLocation.setOnClickListener(this);
		orderFood.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		if (R.id.nearest_location_button == v.getId()) {
			startActivity(new Intent(this, MapActivity.class));
		}
		if (R.id.order_food_button == v.getId()) {
			startActivity(new Intent(this, OrderFoodActivity.class));
		}

	}

	public void turnOnGpsDialog() {
		if (!isGpsEnabled()) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);

			builder.setTitle("Enable GPS");
			builder.setMessage("GPS is turned off. It is recommended that you enable GPS. Do you want to turn on GPS ");
			builder.setPositiveButton("YES",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							Intent turnOnGpsIntent = new Intent(
									Settings.ACTION_LOCATION_SOURCE_SETTINGS);
							startActivity(turnOnGpsIntent);
							dialog.dismiss();
						}

					});
			builder.setNegativeButton("NO",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}

					});
			AlertDialog alert = builder.create();
			alert.show();
		}
	}

	public Boolean isGpsEnabled() {
		LocationManager mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		boolean enabled = mlocManager
				.isProviderEnabled(LocationManager.GPS_PROVIDER);
		return enabled;
	}
}