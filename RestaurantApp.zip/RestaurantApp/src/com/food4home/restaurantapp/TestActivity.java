package com.food4home.restaurantapp;

import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.location.LocationClient;

public class TestActivity extends FragmentActivity implements
		GooglePlayServicesClient.ConnectionCallbacks,
		GooglePlayServicesClient.OnConnectionFailedListener {
	LocationClient mLocationClient;
	Location mCurrentLocation;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.activity_test);
		mLocationClient = new LocationClient(this, this, this);
	}

	@Override
	protected void onStart() {
		super.onStart();
		mLocationClient.connect();
		Log.d("aasdasd", "Hello World2222");
	}

	@Override
	protected void onStop() {
		mLocationClient.disconnect();
		super.onStop();

	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onConnected(Bundle arg0) {
		mCurrentLocation = mLocationClient.getLastLocation();

		Log.d("latsssss", "" + mCurrentLocation.getLatitude());
		Log.d("lng", "" + mCurrentLocation.getLongitude());

	}

	@Override
	public void onDisconnected() {
		// TODO Auto-generated method stub

	}

}
