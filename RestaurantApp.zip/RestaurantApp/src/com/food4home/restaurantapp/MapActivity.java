package com.food4home.restaurantapp;

//import com.example.mapdemo.R;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends FragmentActivity implements
		GooglePlayServicesClient.ConnectionCallbacks,
		GooglePlayServicesClient.OnConnectionFailedListener {
	private GoogleMap mMap;
	private HashMap<Integer, ArrayList<String>> locations = new HashMap<Integer, ArrayList<String>>();
	// HashMap<Integer, ArrayList<String>> locations;
	private LocationClient mLocationClient;
	Location mCurrentLocation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		// startActivity(new Intent(this, TestActivity.class));
		mLocationClient = new LocationClient(this, this, this);
	}

	@Override
	protected void onStart() {
		super.onStart();
		mLocationClient.connect();

	}

	@Override
	protected void onStop() {
		mLocationClient.disconnect();
		super.onStop();

	}

	@Override
	protected void onResume() {
		super.onResume();
		SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);
		mMap = fm.getMap();
		mMap.setMyLocationEnabled(true);

	}

	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onConnected(Bundle arg0) {
		mCurrentLocation = mLocationClient.getLastLocation();
		RestaurantsAsyncTask restaurantAsync = new RestaurantsAsyncTask();
		String url = getGoogleMapsUrl(mCurrentLocation.getLatitude(),
				mCurrentLocation.getLongitude());
		Log.d("asd", "" + mCurrentLocation.getLatitude());
		restaurantAsync.execute(url);
	}

	@Override
	public void onDisconnected() {

	}

	// Getting nearest restaurants from google maps
	class RestaurantsAsyncTask extends AsyncTask<String, Void, Void> {

		private ProgressDialog progressDialog = new ProgressDialog(
				MapActivity.this);
		InputStream inputStream = null;
		String result = "";

		@Override
		protected void onPreExecute() {
			progressDialog.setMessage("Downloading your data...");
			progressDialog.show();
		}

		@Override
		protected Void doInBackground(String... params) {
			HttpClient httpClient = new DefaultHttpClient();
			HttpGet httpGet = new HttpGet(params[0]);
			try {
				HttpResponse httpResponse = httpClient.execute(httpGet);
				InputStream inputStream = httpResponse.getEntity().getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);
				StringBuilder strData = new StringBuilder();
				String chunk = null;
				// JSONArray jPlaces = new JSONArray();

				while ((chunk = bufferedReader.readLine()) != null) {
					strData.append(chunk);

				}
				try {
					JSONObject jObject = new JSONObject(strData.toString());

					for (int i = 0; i < jObject.getJSONArray("results")
							.length(); i++) {
						String jStr = jObject.getJSONArray("results")
								.getJSONObject(i).getString("geometry");
						JSONObject jOb = new JSONObject(jStr);
						jStr = jOb.getString("location").toString();
						JSONObject jOb2 = new JSONObject(jStr);
						ArrayList<String> arrList = new ArrayList<String>();
						arrList.add(jOb2.getString("lat"));
						arrList.add(jOb2.getString("lng"));
						locations.put(i, arrList);
					}

					Log.d("qwioeuqwioeuqiowue", locations.toString());
				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			Iterator<Integer> keyLocaitions = locations.keySet().iterator();

			while (keyLocaitions.hasNext()) {
				Integer key = keyLocaitions.next();
				try {
					JSONArray jsArray = new JSONArray(locations.get(key));
					mMap.addMarker(new MarkerOptions().position(new LatLng(
							Double.parseDouble(jsArray.get(0).toString()),
							Double.parseDouble(jsArray.get(1).toString()))));
				} catch (JSONException e) {
					e.printStackTrace();
				}

			}
			LatLng mLocation = new LatLng(mCurrentLocation.getLatitude(),
					mCurrentLocation.getLongitude());
			mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mLocation, 14));
		}
	}

	public String getGoogleMapsUrl(Double lat, Double lng) {

		return "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
				+ lat
				+ ","
				+ lng
				+ "&radius=5000&keyword=restaurants&sensor=true&language=en&key=AIzaSyAstD-wYrLE_2chILXJB9_RD1M8E1U_SDY";
	}

}