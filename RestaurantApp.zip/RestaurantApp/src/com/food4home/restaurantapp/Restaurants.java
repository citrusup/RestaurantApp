package com.food4home.restaurantapp;

import java.util.ArrayList;
import java.util.HashMap;

import android.widget.TextView;

import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.GoogleMap;

public class Restaurants {
	private static String googleMapUrl;

	private GoogleMap mMap;
	HashMap<Integer, ArrayList<String>> locations = new HashMap<Integer, ArrayList<String>>();
	private LocationClient mLocationClient;
	private TextView mMessageView;
	private static final LocationRequest REQUEST = LocationRequest.create()
			.setInterval(5000) // 5 seconds
			.setFastestInterval(16) // 16ms = 60fps
			.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

}
