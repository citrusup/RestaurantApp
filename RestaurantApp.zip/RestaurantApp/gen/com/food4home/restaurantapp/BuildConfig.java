/** Automatically generated file. DO NOT MODIFY */
package com.food4home.restaurantapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}